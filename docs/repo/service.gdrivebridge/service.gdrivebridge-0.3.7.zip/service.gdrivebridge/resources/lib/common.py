"""Shared helpers: settings, paths, logging, TLS and small file utilities."""
import calendar
import glob
import json
import os
import secrets
import socket
import ssl
import threading
import time
import weakref

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'service.gdrivebridge'
STATUS_FILE = 'status.json'   # written by the service, read by the menu script


def status_path():
    return os.path.join(profile_dir(), STATUS_FILE)

# setting id -> (type, default)
SETTINGS = {
    'client_id': ('str', ''),
    'client_secret': ('str', ''),
    'show_shared': ('bool', True),
    'show_drives': ('bool', True),
    'hide_dot': ('bool', True),
    'hide_archives': ('bool', True),
    'show_starred': ('bool', True),
    'heic_as_jpeg': ('bool', True),
    'poll_interval': ('int', 60),
    'webdav_port': ('int', 8765),
    'lan_share': ('bool', False),
    'lan_user': ('str', 'kodi'),
    'lan_password': ('str', ''),
    'setup_mode': ('int', 1),          # 0 = always on, 1 = only when opened from Kodi (default)
    'setup_port': ('int', 8766),
    'lan_address': ('str', ''),
    'lan_address_detected': ('str', ''),   # shown (greyed out) above the override; never read back
    'relay_url': ('str', ''),
    'debug': ('bool', False),
}
SETUP_ALWAYS, SETUP_ON_DEMAND = 0, 1

_ssl_ctx = None
_paths = {}
DEBUG = False   # set by the service; read without touching Kodi (see debug())


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def addon_path():
    if 'addon' not in _paths:
        _paths['addon'] = xbmcvfs.translatePath(addon().getAddonInfo('path'))
    return _paths['addon']


def profile_dir():
    if 'profile' not in _paths:
        path = xbmcvfs.translatePath(addon().getAddonInfo('profile'))
        os.makedirs(path, exist_ok=True)
        _paths['profile'] = path
    return _paths['profile']


# ---- stopping -----------------------------------------------------------
# Kodi waits, with no time limit, for every thread of a stopping service to end, and an
# add-on update waits for that (11-09: an update hung there). Its kill only reaches threads
# running Python, not ones blocked in a socket or a Kodi call. So when the service stops,
# every loop and retry checks `stopping`, open Google connections are cut, and background
# threads stop calling into Kodi.
stopping = threading.Event()
# Kodi installs add-on updates a second or two after startup, stopping this service then.
# Background Google traffic waits until this time so that stop finds nothing in flight
# (SlyGuy Common waits 10 s on boot for the same reason). Set by Bridge.start().
quiet_until = 0
_connections = weakref.WeakSet()       # outgoing HTTPS connections, cut by abort_network()
_connections_lock = threading.Lock()


def track(conn):
    """Register an http.client connection so abort_network() can interrupt it."""
    with _connections_lock:
        _connections.add(conn)
    return conn


def https_connection(host, timeout=30):
    """A tracked HTTPS connection whose TLS handshake can be interrupted too.

    http.client's own connect() only sets `sock` once the handshake is done (the plain
    socket is closed into the TLS one), so a stalled handshake couldn't be cut."""
    import http.client

    class Connection(http.client.HTTPSConnection):
        def connect(self):
            http.client.HTTPConnection.connect(self)
            # a connection opened while (or just after) abort_network() ran must not live on
            if stopping.is_set():
                self.sock.close()
                raise OSError('the service is stopping')
            self.sock = ssl_context().wrap_socket(self.sock, server_hostname=self.host,
                                                  do_handshake_on_connect=False)
            self.sock.do_handshake()

    return track(Connection(host, timeout=timeout, context=ssl_context()))


def wait_until_quiet():
    """Wait out the startup quiet time. Returns False if the service is stopping."""
    delay = quiet_until - time.time()
    return not (delay > 0 and stopping.wait(delay)) and not stopping.is_set()


def abort_network():
    """Wake every thread blocked on a Google connection (shutdown() wakes a blocked recv;
    close() from another thread doesn't)."""
    with _connections_lock:
        conns = list(_connections)
    for conn in conns:
        sock = getattr(conn, 'sock', None)
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


def https_post(url, fields, timeout=30):
    """POST a form; returns (status, body bytes). Raises OSError when Google can't be
    reached. The connection is tracked, so stopping the service interrupts it."""
    import http.client
    import urllib.parse
    parts = urllib.parse.urlsplit(url)
    conn = https_connection(parts.netloc, timeout)
    try:
        conn.request('POST', parts.path, urllib.parse.urlencode(fields),
                     {'Content-Type': 'application/x-www-form-urlencoded'})
        resp = conn.getresponse()
        return resp.status, resp.read()
    except http.client.HTTPException as e:
        raise OSError(str(e))
    finally:
        conn.close()


# ---- requests from the menu ---------------------------------------------
# The menu asks the service for things (open the setup page with this PIN, sign out, reset)
# in a private file in the profile folder; its Kodi notification only says "look". The
# notification can't carry the request itself: JSONRPC.NotifyAll reaches every connected
# remote-control app (port 9090), and anyone who can reach Kodi can send one.
REQUEST_MAX_AGE = 30        # seconds


def write_request(command, data=None):
    path = os.path.join(profile_dir(), 'request-%s.json' % secrets.token_hex(8))
    write_json(path, {'command': command, 'data': data or {}, 't': time.time()}, private=True)


def take_requests():
    """The menu's recent requests, oldest first. Every request file is removed, stale ones
    too, so a later notification can't set an old request off again."""
    now = time.time()
    found = []
    for path in glob.glob(os.path.join(profile_dir(), 'request-*.json')):
        req = read_json(path)
        try:
            os.remove(path)
        except OSError:
            continue                    # taken by another call meanwhile
        t = req.get('t') if isinstance(req, dict) else None
        if isinstance(t, (int, float)) and 0 <= now - t < REQUEST_MAX_AGE:
            found.append(req)
    return sorted(found, key=lambda r: r['t'])

def log(msg, level=xbmc.LOGINFO):
    if stopping.is_set() and threading.current_thread() is not threading.main_thread():
        return      # see `stopping`: a background thread must not call into Kodi now
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def debug(msg):
    # Must not call into Kodi's settings: the WebDAV handlers log through here, and
    # Kodi's GUI thread can be blocked waiting on that very request (deadlock until
    # Kodi's curl timeout; seen 11-09 on "Add network location").
    if DEBUG:
        log(msg, xbmc.LOGINFO)


def set_debug(value):
    global DEBUG
    DEBUG = bool(value)


def lang(string_id):
    return addon().getLocalizedString(string_id)


def get_setting(key, a=None):
    kind, default = SETTINGS[key]
    a = a or addon()
    try:
        if kind == 'bool':
            return a.getSettingBool(key)
        if kind == 'int':
            return a.getSettingInt(key)
        return a.getSettingString(key)
    except Exception:
        return default


SETTINGS_REV = 1


def migrate_settings():
    """One-time changes for installs upgraded from older versions. Kodi keeps a saved
    value even when the add-on's default changes, so a new default needs this."""
    path = os.path.join(profile_dir(), 'settings_rev')
    try:
        with open(path) as f:
            rev = int(f.read().strip() or 0)
    except (OSError, ValueError):
        rev = 0
    if rev >= SETTINGS_REV:
        return
    if rev < 1 and get_setting('setup_mode') == SETUP_ALWAYS:
        # 0.3.0: the setup page opens only from Kodi's menu (it used to be always on)
        set_setting('setup_mode', SETUP_ON_DEMAND)
        log('setup page now opens only from the menu; it can be set back to always on')
    with open(path, 'w') as f:
        f.write(str(SETTINGS_REV))


def get_settings():
    a = addon()
    return {key: get_setting(key, a) for key in SETTINGS}


def set_setting(key, value):
    kind = SETTINGS[key][0]
    a = addon()
    if kind == 'bool':
        a.setSettingBool(key, bool(value))
    elif kind == 'int':
        a.setSettingInt(key, int(value))
    else:
        a.setSettingString(key, str(value))


def lan_address():
    """The address for the QR code: the user's override, else the detected one."""
    return get_setting('lan_address').strip() or detect_lan_address()


def detect_lan_address():
    """This device's home-network IPv4 address (not a VPN tunnel's).

    Kodi's getIPAddress() can return the VPN address when a VPN app is up, which
    would put an unreachable address in the QR code. Prefer a private address on
    a non-tunnel interface, then fall back to Kodi's answer.
    """
    candidates = []
    try:
        import subprocess
        out = subprocess.run(['ip', '-4', '-o', 'addr', 'show'], capture_output=True, text=True,
                             timeout=5).stdout
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 4 or parts[2] != 'inet':
                continue
            iface, addr = parts[1], parts[3].split('/')[0]
            if iface == 'lo' or iface.startswith(('tun', 'ppp', 'wg', 'ipsec', 'nord')):
                continue
            candidates.append(addr)
    except Exception:
        pass
    if not candidates:
        try:
            candidates = _ioctl_addresses()
        except Exception as e:
            log('address lookup failed: %r' % e)

    def private(a):
        return a.startswith(('192.168.', '10.')) or (
            a.startswith('172.') and 16 <= int(a.split('.')[1]) <= 31)

    for addr in candidates:
        if private(addr):
            return addr
    if candidates:
        return candidates[0]
    return xbmc.getIPAddress() or '127.0.0.1'


def _ioctl_addresses():
    """Interface addresses via SIOCGIFADDR, for when 'ip' is blocked (newer Android)."""
    import fcntl
    import socket
    import struct
    out = []
    names = []
    try:
        names = [n for _, n in socket.if_nameindex()]
    except (AttributeError, OSError):      # missing from Kodi's Android Python
        try:
            names = os.listdir('/sys/class/net')
        except OSError:
            pass
    names = names or ['eth0', 'wlan0', 'eth1', 'wlan1']
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for name in names:
            if name == 'lo' or name.startswith(('tun', 'ppp', 'wg', 'ipsec', 'nord')):
                continue
            try:
                req = struct.pack('256s', name[:15].encode())
                res = fcntl.ioctl(sock.fileno(), 0x8915, req)   # SIOCGIFADDR
                out.append(socket.inet_ntoa(res[20:24]))
            except OSError:
                continue
    finally:
        sock.close()
    return out




def ssl_context():
    """TLS context with a CA bundle that exists on every Kodi platform."""
    global _ssl_ctx
    if _ssl_ctx is None:
        cafile = None
        try:
            import certifi
            cafile = certifi.where()
        except ImportError:
            kodi_ca = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
            if os.path.isfile(kodi_ca):
                cafile = kodi_ca
        _ssl_ctx = ssl.create_default_context(cafile=cafile)
    return _ssl_ctx


def read_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, data, private=False):
    """Write atomically; private files are readable by the owner only.

    Each write has its own temporary file: the same file can be written from several
    threads (status.json) or from the menu's own interpreter (pending.json) at once."""
    tmp = '%s.%s.tmp' % (path, secrets.token_hex(4))
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(tmp, flags, 0o600 if private else 0o644)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, separators=(',', ':'))
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def parse_rfc3339(value):
    """Drive timestamp ('2024-01-02T03:04:05.678Z') to epoch seconds."""
    if not value:
        return 0
    try:
        base = value[:19]
        t = time.strptime(base, '%Y-%m-%dT%H:%M:%S')
        return calendar.timegm(t)
    except ValueError:
        return 0


def human_size(n):
    if n is None:
        return ''
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return ('%d %s' % (n, unit)) if unit == 'B' else ('%.1f %s' % (n, unit))
        n /= 1024.0
