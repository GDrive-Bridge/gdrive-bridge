"""GDrive Bridge menu: setup QR, status, refresh, sign out, help."""
import glob
import json
import os
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

from . import common, qr, sources
from .slideshow import PICTURE_EXTS

TITLE = 'GDrive Bridge'
REPO_ID = 'repository.gdrivebridge'
REPO_URL = 'https://gdrive-bridge.github.io/gdrive-bridge/repo/'
UPDATES_HELP = (
    'This copy of GDrive Bridge doesn\'t update itself: it was installed from a zip file, and '
    'Kodi only updates add-ons from the repository they came from.[CR][CR]'
    '[B]1.[/B] Settings > File manager > Add source: enter [B]%s[/B] and name it '
    'GDrive Bridge.[CR]'
    '[B]2.[/B] Settings > Add-ons > Install from zip file > GDrive Bridge: choose '
    'repository.gdrivebridge-1.0.0.zip.[CR]'
    '[B]3.[/B] Add-ons > My add-ons > Services > GDrive Bridge: choose [B]Versions[/B] and pick '
    'the version from GDrive Bridge Repository.[CR][CR]'
    'Your sign-in and settings are kept. After that Kodi installs new versions automatically.'
    % REPO_URL)
BACK_ACTIONS = (9, 10, 92, 216, 247, 257, 275, 61448)


def service_status():
    return common.read_json(common.status_path())


def notify(command, data=None):
    """Ask the service to do something. The request (with the setup PIN and QR link) goes in
    a private file; the notification only wakes the service, because Kodi passes it on to
    every connected remote-control app (see common.take_requests)."""
    common.write_request(command, data)
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
        'params': {'sender': common.ADDON_ID, 'message': 'request', 'data': {}}}))


def wait_for(check, seconds):
    monitor = xbmc.Monitor()
    end = time.time() + seconds
    while time.time() < end:
        st = service_status()
        if st and check(st):
            return st
        if monitor.waitForAbort(0.25):
            break
    return service_status()


class SetupDialog(xbmcgui.WindowDialog):
    """Full-screen panel with a QR code for the setup page; closes itself after sign-in."""

    def __init__(self, link, st, pin):
        xbmcgui.WindowDialog.__init__(self)
        self.done = threading.Event()
        self.was_signed_in = st['signed_in']
        profile = common.profile_dir()
        for old in glob.glob(os.path.join(profile, 'qr-*.png')):
            try:
                os.remove(old)
            except OSError:
                pass
        qr_path = os.path.join(profile, 'qr-%s.png' % secrets.token_hex(4))   # new name: no texture cache
        qr.save_qr(link, qr_path, scale=12)
        bg = os.path.join(profile, 'panel.png')
        if not os.path.exists(bg):
            qr.write_png(bg, 1, 1, lambda x, y: (14, 20, 27, 244))
        icon = os.path.join(common.addon_path(), 'resources', 'icon.png')

        white, muted, accent = '0xFFFFFFFF', '0xFFB8C7D4', '0xFF17B2E7'
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, bg))
        self.addControl(xbmcgui.ControlImage(80, 46, 72, 72, icon))
        self.addControl(xbmcgui.ControlLabel(172, 62, 1000, 40, '[B]GDrive Bridge setup[/B]',
                                             font='font13', textColor=white))
        self.addControl(xbmcgui.ControlImage(80, 150, 420, 420, qr_path, aspectRatio=0))
        body = xbmcgui.ControlTextBox(540, 150, 680, 130, font='font13', textColor=white)
        self.addControl(body)
        body.setText('Scan the code with your phone\'s camera to open the setup page. Everything '
                     'can be set there: your Google client, sign-in and all settings.[CR][CR]'
                     'On a computer or tablet, open this address and enter the PIN:')
        self.addControl(xbmcgui.ControlLabel(540, 290, 680, 40, '[B]%s[/B]' % st['setup_url'],
                                             font='font13', textColor=accent))
        self.addControl(xbmcgui.ControlLabel(540, 334, 680, 40, 'PIN: [B]%s[/B]' % pin,
                                             font='font13', textColor=white))
        self.state = xbmcgui.ControlLabel(540, 420, 680, 40, '', font='font13', textColor=muted)
        self.addControl(self.state)
        self.addControl(xbmcgui.ControlLabel(540, 530, 680, 40, 'Press Back to close.',
                                             font='font13', textColor=muted))
        self._show_state(st)

    def _show_state(self, st):
        if st['signed_in'] and not st['auth_error']:
            self.state.setLabel('Signed in as %s' % (st['email'] or 'your account'))
        elif not st['has_client']:
            self.state.setLabel('Waiting for your Google client details...')
        else:
            self.state.setLabel('Waiting for Google sign-in...')

    def poll(self):
        monitor = xbmc.Monitor()
        while not self.done.is_set() and not monitor.abortRequested():
            st = service_status()
            if st:
                self._show_state(st)
                if st['signed_in'] and not st['auth_error'] and not self.was_signed_in:
                    xbmcgui.Dialog().notification(TITLE, 'Signed in as %s' % st['email'],
                                                  os.path.join(common.addon_path(), 'resources',
                                                               'icon.png'), 4000)
                    self.done.wait(3)
                    self.close()
                    return
            self.done.wait(1)

    def onAction(self, action):
        if action.getId() in BACK_ACTIONS:
            self.close()


def open_setup():
    token = secrets.token_urlsafe(9)
    pin = '%06d' % secrets.randbelow(1000000)     # one-time, like the QR link
    asked = time.time() - 1
    notify('setup', {'token': token, 'pin': pin})
    # the status file outlives a killed Kodi, so wait for one written after this request
    st = wait_for(lambda s: s.get('updated', 0) >= asked and (s['setup_running'] or
                                                              s['setup_error']), 5)
    if st is None:
        xbmcgui.Dialog().ok(TITLE, 'The GDrive Bridge service isn\'t running. Restart Kodi and try '
                                   'again.')
        return
    if not st['setup_running']:
        xbmcgui.Dialog().ok(TITLE, st['setup_error'] or 'The setup page couldn\'t start.')
        return
    dialog = SetupDialog(st['setup_url'] + '?t=' + token, st, pin)
    poller = threading.Thread(target=dialog.poll)
    poller.daemon = True
    poller.start()
    dialog.doModal()
    dialog.done.set()
    del dialog


def show_status(st):
    synced = time.strftime('%d %b %H:%M:%S', time.localtime(st['synced'])) if st['synced'] \
        else 'not yet'
    lines = [
        '[B]Account:[/B] %s' % (st['email'] or 'signed in') if st['signed_in'] else
        '[B]Account:[/B] not signed in',
    ]
    if st['auth_error']:
        lines.append('[B]Sign-in problem:[/B] %s' % st['auth_error'])
    lines += [
        '[B]Kodi source path:[/B] %s' % st['webdav'],
        '[B]Drive items cached:[/B] %d in %d folders' % (st['items'], st['folders']),
        '[B]Last change check:[/B] %s' % synced,
        '[B]Setup page:[/B] %s%s' % (st['setup_url'],
                                     '' if st['setup_running'] else ', closed now'),
    ]
    lines.append('[B]Updates:[/B] %s' % ('automatic, from GDrive Bridge Repository'
                                         if has_repository() else
                                         'not automatic (see "Turn on automatic updates")'))
    if st['error']:
        lines.append('[B]Last error:[/B] %s' % st['error'])
    for a in st.get('accounts', [])[1:]:
        lines.append('[B]Also:[/B] %s, in folder /%s/%s' % (
            a['email'] or 'unknown', a['folder'] or '?',
            ' - sign-in problem: ' + a['auth_error'] if a['auth_error'] else ''))
    xbmcgui.Dialog().textviewer('%s status' % TITLE, '[CR]'.join(lines))


def search(st):
    """Ask for a term and open Drive's matching files and folders as a Kodi folder."""
    accounts = [a for a in st.get('accounts', []) if a['signed_in']]
    prefix = ''
    if len(accounts) > 1:
        labels = ['%s (%s)' % (a['email'], 'main' if a['id'] == 'main' else a['folder'])
                  for a in accounts]
        choice = xbmcgui.Dialog().select('Search which account?', labels)
        if choice < 0:
            return
        if accounts[choice]['id'] != 'main':
            prefix = urllib.parse.quote(accounts[choice]['folder'], safe='') + '/'
    term = xbmcgui.Dialog().input('Search Google Drive (file or folder name)').strip()
    if not term:
        return
    rel = '%sSearch/%s/' % (prefix, urllib.parse.quote(term, safe=''))
    # Run the search here first, so the window opens from the add-on's cache: Kodi's
    # screen must not wait on Google (see cache.py, read-ahead).
    busy = xbmcgui.DialogProgressBG()
    busy.create(TITLE, 'Searching Google Drive for "%s"...' % term)
    try:
        port = st['webdav'].rstrip('/').rsplit(':', 1)[1]
        req = urllib.request.Request('http://127.0.0.1:%s/%s' % (port, rel), method='PROPFIND',
                                     headers={'Depth': '1'})
        with urllib.request.urlopen(req, timeout=90) as resp:
            found = resp.read().count(b'<D:response>') - 1
    except (urllib.error.URLError, OSError, ValueError) as e:
        busy.close()
        xbmcgui.Dialog().ok(TITLE, 'The search didn\'t work: %s' % e)
        return
    busy.close()
    if found <= 0:
        xbmcgui.Dialog().ok(TITLE, 'Nothing in Google Drive is named like "%s".' % term)
        return
    xbmc.executebuiltin('ActivateWindow(Videos,"%s%s",return)' % (st['webdav'], rel))


def _webdav_port(st):
    return st['webdav'].rstrip('/').rsplit(':', 1)[1]


def list_folder(st, rel):
    """(subfolder names, picture count) of a WebDAV folder, from the service."""
    req = urllib.request.Request('http://127.0.0.1:%s/%s' % (_webdav_port(st), rel),
                                 method='PROPFIND', headers={'Depth': '1'})
    with urllib.request.urlopen(req, timeout=90) as resp:
        root = ET.fromstring(resp.read())
    folders, pictures = [], 0
    for r in root.findall('{DAV:}response')[1:]:            # the first is the folder itself
        href = r.findtext('{DAV:}href') or ''
        name = urllib.parse.unquote(href.rstrip('/').rsplit('/', 1)[-1])
        if r.find('.//{DAV:}collection') is not None:
            folders.append(name)
        elif name.lower().endswith(PICTURE_EXTS):
            pictures += 1
    return folders, pictures


def choose_folder(st, title, use_label):
    """Browse the Drive folder by folder. `use_label(path, folders, pictures)` gives the
    'use this folder' entry for a level, or None where there is none. Returns
    (path segments, subfolder names) or None if cancelled."""
    path = []
    while True:
        rel = ''.join(urllib.parse.quote(p, safe='') + '/' for p in path)
        try:
            folders, pictures = list_folder(st, rel)
        except (urllib.error.URLError, OSError, ValueError, ET.ParseError) as e:
            xbmcgui.Dialog().ok(TITLE, 'Google Drive can\'t be read right now: %s' % e)
            return None
        options = []
        label = use_label(path, folders, pictures)
        if label:
            options.append((label, 'use'))
        if path:
            options.append(('..', 'up'))
        options += [(name, name) for name in folders]
        heading = '%s: %s' % (title, '/'.join(path) or 'choose a folder')
        choice = xbmcgui.Dialog().select(heading, [label for label, _ in options])
        if choice < 0:
            return None
        action = options[choice][1]
        if action == 'use':
            return path, folders
        if action == 'up':
            path.pop()
        else:
            path.append(action)


def live_slideshow(st):
    """Pick a Drive folder and start a slideshow of it that picks up new pictures."""
    if not st['signed_in']:
        xbmcgui.Dialog().ok(TITLE, 'Sign in first: choose Set up on phone or computer.')
        return
    picked = choose_folder(st, 'Live slideshow', lambda path, folders, pictures: (
        '[B]Show this folder[/B] (%d picture%s here)' % (pictures, '' if pictures == 1 else 's')
        if path else None))
    if picked is None:
        return
    path, folders = picked
    rel = ''.join(urllib.parse.quote(p, safe='') + '/' for p in path)
    recursive = bool(folders) and xbmcgui.Dialog().yesno(
        TITLE, 'Include the pictures in its subfolders too?')
    req_id = secrets.token_hex(4)
    notify('slideshow', {'path': rel, 'recursive': recursive, 'id': req_id})
    busy = xbmcgui.DialogProgressBG()
    busy.create(TITLE, 'Reading %s...' % path[-1])
    try:
        st = wait_for(lambda s: (s.get('slideshow') or {}).get('req') == req_id, 180)
    finally:
        busy.close()
    result = (st or {}).get('slideshow') or {}
    if result.get('req') != req_id:
        xbmcgui.Dialog().ok(TITLE, 'The slideshow didn\'t start: GDrive Bridge took too long '
                                   'to read the folder. Try again in a moment.')
    elif not result.get('ok'):
        xbmcgui.Dialog().ok(TITLE, result.get('message') or 'The slideshow didn\'t start.')
    else:
        xbmcgui.Dialog().notification(TITLE, 'New pictures show up within %d seconds'
                                      % max(15, common.get_settings()['poll_interval']),
                                      time=6000)


SOURCE_KINDS = [('Videos', 'video'), ('Music', 'music'), ('Pictures', 'pictures')]


def add_to_kodi(st):
    """Add Drive folders as Kodi sources (sources.xml), then restart Kodi to load them."""
    if not st['signed_in']:
        xbmcgui.Dialog().ok(TITLE, 'Sign in first: choose Set up on phone or computer.')
        return
    path = xbmcvfs.translatePath('special://profile/sources.xml')
    base = 'dav://127.0.0.1:%s/' % _webdav_port(st)
    added = []
    while True:
        labels = [label for label, _ in SOURCE_KINDS] + ['Show the steps to do it by hand']
        kind = xbmcgui.Dialog().select('Add Google Drive to...', labels)
        if kind < 0:
            break
        if kind == len(SOURCE_KINDS):
            manual = xbmcgui.Dialog().select('Steps for...', [l for l, _ in SOURCE_KINDS])
            if manual >= 0:
                (add_source_help, add_music_help, add_pictures_help)[manual](st)
            return
        label, section = SOURCE_KINDS[kind]
        picked = choose_folder(st, 'Add to %s' % label, lambda p, folders, pictures: (
            '[B]Use this folder[/B]' if p else '[B]Use the whole Drive[/B]'))
        if picked is None:
            continue
        segments = picked[0]
        if section != 'pictures' and len(segments) <= 1 and not xbmcgui.Dialog().yesno(
                TITLE, 'Scanning %s into the library means Kodi opens every folder in it, '
                'which can take hours on a big Drive. Add it anyway? (Choosing the folder '
                'that holds your %s is quicker.)' % (
                    '/'.join(segments) or 'the whole Drive', label.lower())):
            continue
        url = base + ''.join(urllib.parse.quote(s, safe='') + '/' for s in segments)
        name = xbmcgui.Dialog().input('Name for this source', segments[-1] if segments
                                      else 'Google Drive').strip()
        if not name:
            continue
        try:
            used = sources.add(path, section, name, url)
        except (OSError, ValueError, ET.ParseError) as e:
            xbmcgui.Dialog().ok(TITLE, 'Kodi\'s sources file couldn\'t be changed: %s' % e)
            return
        if used is None:
            xbmcgui.Dialog().ok(TITLE, 'That folder is already one of your %s sources.' % label)
        else:
            added.append('%s: %s' % (label, used))
        if not xbmcgui.Dialog().yesno(TITLE, 'Add another folder?'):
            break
    if not added:
        return
    android = xbmc.getCondVisibility('System.Platform.Android')
    lines = ['Added ' + ', '.join(added) + '.', '',
             'Kodi reads its sources when it starts, so it needs restarting. Until then, '
             'don\'t add or change sources by hand, or Kodi will save over these.', '',
             'For films or TV shows, set the content type afterwards: highlight the source, '
             'open its menu and choose Set content.']
    question = 'Quit Kodi now? (Then open it again.)' if android else 'Restart Kodi now?'
    if xbmcgui.Dialog().yesno(TITLE, '[CR]'.join(lines) + '[CR][CR]' + question):
        xbmc.executebuiltin('Quit' if android else 'RestartApp')


def add_pictures_help(st):
    xbmcgui.Dialog().textviewer('Add Google Drive to Pictures', '[CR]'.join([
        '1. Go to [B]Pictures[/B] and choose [B]Add pictures...[/B]',
        '2. Choose [B]Browse[/B], then [B]Add network location...[/B]',
        '   Protocol: [B]WebDAV server (HTTP)[/B], Server address: [B]127.0.0.1[/B], '
        'Port: [B]%s[/B]. Leave the rest empty and choose OK.' % st['webdav'].rsplit(':', 1)[1]
        .strip('/'),
        '   (Or type [B]%s[/B] as the path.)' % st['webdav'],
        '3. Open it, pick a photo folder, choose OK and name it.',
        '',
        'Browse it and press [B]Play[/B] on a folder for a slideshow. iPhone HEIC photos are',
        'shown using Google\'s JPEG version (setting: Show iPhone HEIC photos as JPEG).',
    ]))
    if xbmcgui.Dialog().yesno(TITLE, 'Open the Pictures sources now?'):
        xbmc.executebuiltin('ActivateWindow(Pictures,sources://pictures/,return)')


def add_music_help(st):
    xbmcgui.Dialog().textviewer('Add Google Drive to Music', '[CR]'.join([
        '1. Go to [B]Music > Files > Add music...[/B]',
        '2. Choose [B]Browse[/B], then [B]Add network location...[/B]',
        '   Protocol: [B]WebDAV server (HTTP)[/B], Server address: [B]127.0.0.1[/B], '
        'Port: [B]%s[/B]. Leave the rest empty and choose OK.' % _webdav_port(st),
        '   (Or type [B]%s[/B] as the path.)' % st['webdav'],
        '3. Open it, pick your music folder, choose OK and name it.',
        '',
        'Browse it and play.',
    ]))
    if xbmcgui.Dialog().yesno(TITLE, 'Open the Music sources now?'):
        xbmc.executebuiltin('ActivateWindow(Music,sources://music/,return)')


def add_source_help(st):
    xbmcgui.Dialog().textviewer('Add Google Drive to Videos', '[CR]'.join([
        '1. Go to [B]Videos > Files > Add videos...[/B]',
        '2. Choose [B]Browse[/B], then [B]Add network location...[/B]',
        '   Protocol: [B]WebDAV server (HTTP)[/B], Server address: [B]127.0.0.1[/B], '
        'Port: [B]%s[/B]. Leave the rest empty and choose OK.' % st['webdav'].rsplit(':', 1)[1]
        .strip('/'),
        '   (Or type [B]%s[/B] as the path.)' % st['webdav'],
        '3. Open it, pick a folder such as My Drive/Movies, and choose OK.',
        '4. Name the source, then set the content type (Movies or TV shows) so Kodi scans it.',
        '',
        'Leave "Clean library on startup" off. A scan never removes items; only cleaning does.',
    ]))
    if xbmcgui.Dialog().yesno(TITLE, 'Open the Videos sources now?'):
        xbmc.executebuiltin('ActivateWindow(Videos,sources://video/,return)')


def has_repository():
    return xbmc.getCondVisibility('System.HasAddon(%s)' % REPO_ID)


def updates_help():
    xbmcgui.Dialog().textviewer('%s: automatic updates' % TITLE, UPDATES_HELP)


def updates_hint_once():
    """Point a zip install at the repository, once (the menu keeps an entry for it)."""
    marker = os.path.join(common.profile_dir(), 'updates_hint_shown')
    if has_repository() or os.path.exists(marker):
        return
    try:
        open(marker, 'w').close()
    except OSError:
        return
    updates_help()


def check_updates():
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmcgui.Dialog().notification(TITLE, 'Checking for updates. A new version installs by itself.')


def reset(st):
    if not xbmcgui.Dialog().yesno(TITLE, 'Reset GDrive Bridge? This signs out every account (also '
                                         'with Google), clears the cached Drive folders and puts '
                                         'all settings back to their defaults. Your Google client '
                                         'ID and secret are kept.'):
        return
    notify('reset')
    wait_for(lambda s: not s['signed_in'] and len(s.get('accounts', [])) <= 1, 10)
    xbmcgui.Dialog().notification(TITLE, 'Reset done. Set up again from the menu.')


def sign_out(st):
    if not st['signed_in']:
        xbmcgui.Dialog().ok(TITLE, 'Not signed in.')
        return
    if xbmcgui.Dialog().yesno(TITLE, 'Sign out %s? The sign-in is also revoked with Google.'
                              % (st['email'] or '')):
        notify('signout')
        wait_for(lambda s: not s['signed_in'], 10)
        xbmcgui.Dialog().notification(TITLE, 'Signed out')


def menu():
    st = service_status()
    if st is None:
        xbmcgui.Dialog().ok(TITLE, 'The GDrive Bridge service isn\'t running yet. Try again in a '
                                   'moment.')
        return
    updates_hint_once()
    entries = [('Set up on phone or computer', open_setup),
               ('Status', lambda: show_status(service_status() or st)),
               ('Refresh Drive folders', lambda: (notify('refresh'), xbmcgui.Dialog().notification(
                   TITLE, 'Re-reading Drive folders'))),
               ('Search Google Drive', lambda: search(service_status() or st)),
               ('Live slideshow', lambda: live_slideshow(service_status() or st)),
               ('Add Google Drive to Kodi', lambda: add_to_kodi(st))]
    if st['signed_in']:
        entries.append(('Sign out', lambda: sign_out(st)))
    if has_repository():
        entries.append(('Check for updates', check_updates))
    else:
        entries.insert(1, ('Turn on automatic updates', updates_help))
    entries.append(('Reset GDrive Bridge', lambda: reset(st)))
    entries.append(('Settings', lambda: common.addon().openSettings()))
    header = '%s - %s' % (TITLE, st['email'] if st['signed_in'] else 'not signed in')
    choice = xbmcgui.Dialog().select(header, [label for label, _ in entries])
    if choice >= 0:
        entries[choice][1]()


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else ''
    if arg == 'setup':
        open_setup()
    elif arg == 'signout':
        st = service_status()
        if st:
            sign_out(st)
    elif arg == 'refresh':
        notify('refresh')
    elif arg == 'search':
        st = service_status()
        if st:
            search(st)
    elif arg == 'slideshow':
        st = service_status()
        if st:
            live_slideshow(st)
    elif arg == 'stopscan':
        # UpdateLibrary(video) cancels a running video scan instead of starting one
        if xbmc.getCondVisibility('Library.IsScanningVideo'):
            xbmc.executebuiltin('UpdateLibrary(video)')
    else:
        menu()
